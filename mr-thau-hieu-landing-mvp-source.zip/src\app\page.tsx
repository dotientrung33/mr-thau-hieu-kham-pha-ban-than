import { AboutSection } from "@/components/landing/AboutSection";
import { BenefitsSection } from "@/components/landing/BenefitsSection";
import { FinalCTASection } from "@/components/landing/FinalCTASection";
import { HeroBenefitsSection } from "@/components/landing/HeroBenefitsSection";
import { HeroSection } from "@/components/landing/HeroSection";
import { ProblemSection } from "@/components/landing/ProblemSection";
import { ProcessSection } from "@/components/landing/ProcessSection";
import { ReportSection } from "@/components/landing/ReportSection";
import { SiteFooter } from "@/components/shared/SiteFooter";
import { SiteHeader } from "@/components/shared/SiteHeader";

export default function Home() {
  return (
    <>
      <SiteHeader />
      <main>
        <HeroSection />
        <HeroBenefitsSection />
        <ProblemSection />
        <BenefitsSection />
        <ReportSection />
        <ProcessSection />
        <AboutSection />
        <FinalCTASection />
      </main>
      <SiteFooter />
    </>
  );
}
