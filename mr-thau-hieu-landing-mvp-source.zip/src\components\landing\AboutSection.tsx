import { MessageCircleQuote, UserRoundCheck } from "lucide-react";
import { landingContent } from "@/content/landing";
import { Container } from "@/components/shared/Container";
import { SectionHeader } from "@/components/shared/SectionHeader";

export function AboutSection() {
  const { about } = landingContent;

  return (
    <section id="mr-thau-hieu" className="bg-brand-tealSoft py-16 sm:py-20 lg:py-[120px]">
      <Container className="grid gap-10 lg:grid-cols-[0.86fr_1.14fr] lg:items-center">
        <div className="rounded-2xl border border-brand-border bg-white p-6 shadow-soft">
          <div className="flex h-20 w-20 items-center justify-center rounded-full bg-brand-teal text-white">
            <UserRoundCheck className="h-9 w-9" aria-hidden="true" />
          </div>
          <h3 className="mt-6 text-2xl font-bold text-brand-teal">{about.title}</h3>
          <p className="mt-2 font-semibold text-brand-charcoal">{about.role}</p>
          <div className="mt-5 grid gap-3">
            {about.stats.map((stat) => (
              <div
                key={stat}
                className="rounded-lg border border-brand-border bg-brand-ivory px-4 py-3 text-sm font-semibold text-brand-teal"
              >
                {stat}
              </div>
            ))}
          </div>
          <p className="mt-3 leading-7 text-brand-muted">
            Đồng hành bằng câu hỏi, cấu trúc và sự quan sát để bạn nhìn rõ chính mình hơn.
          </p>
        </div>

        <div>
          <SectionHeader
            eyebrow={about.eyebrow}
            title="Mr. Thấu Hiểu"
            description={about.description}
          />
          <div className="mt-8 flex flex-wrap gap-3">
            {about.services.map((service) => (
              <span
                key={service}
                className="rounded-full border border-brand-border bg-white px-4 py-2 text-sm font-semibold text-brand-teal"
              >
                {service}
              </span>
            ))}
          </div>
          <blockquote className="mt-8 rounded-xl border-l-4 border-brand-gold bg-white p-6 text-lg font-medium leading-8 text-brand-charcoal shadow-[0_12px_30px_rgba(15,61,62,0.06)]">
            <MessageCircleQuote className="mb-4 h-7 w-7 text-brand-gold" aria-hidden="true" />
            “{about.quote}”
          </blockquote>
        </div>
      </Container>
    </section>
  );
}
