import { Check } from "lucide-react";
import { landingContent } from "@/content/landing";
import { Container } from "@/components/shared/Container";
import { SectionHeader } from "@/components/shared/SectionHeader";

export function BenefitsSection() {
  const { benefits } = landingContent;

  return (
    <section id="nhan-duoc-gi" className="bg-white py-16 sm:py-20 lg:py-[120px]">
      <Container className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:items-start">
        <SectionHeader eyebrow={benefits.eyebrow} title={benefits.title} />
        <div className="grid gap-4">
          {benefits.items.map((item) => (
            <div
              key={item}
              className="flex gap-4 rounded-xl border border-brand-border bg-brand-ivory p-5"
            >
              <div className="mt-1 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-brand-teal text-white">
                <Check className="h-4 w-4" aria-hidden="true" />
              </div>
              <p className="leading-7 text-brand-charcoal">{item}</p>
            </div>
          ))}
        </div>
      </Container>
    </section>
  );
}
