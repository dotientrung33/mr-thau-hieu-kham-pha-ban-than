import { landingContent } from "@/content/landing";
import { links } from "@/config/links";
import { Container } from "@/components/shared/Container";
import { CTAButton } from "@/components/shared/CTAButton";

export function FinalCTASection() {
  const { finalCta } = landingContent;

  return (
    <section className="bg-brand-teal py-16 text-white sm:py-20 lg:py-[120px]">
      <Container>
        <div className="mx-auto max-w-3xl text-center">
          <p className="mb-4 text-sm font-semibold uppercase tracking-[0.16em] text-brand-gold">
            Bắt đầu từ sự rõ ràng
          </p>
          <h2 className="text-3xl font-bold leading-tight sm:text-4xl lg:text-[48px]">
            {finalCta.title}
          </h2>
          <p className="mt-5 text-lg leading-8 text-white/80">{finalCta.description}</p>
          <div className="mt-8">
            <CTAButton href={links.googleForm} variant="light">
              {finalCta.cta}
            </CTAButton>
          </div>
          <p className="mt-5 text-sm leading-6 text-white/70">{finalCta.microcopy}</p>
        </div>
      </Container>
    </section>
  );
}
