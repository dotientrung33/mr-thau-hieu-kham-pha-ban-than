import { CheckCircle2 } from "lucide-react";
import { landingContent } from "@/content/landing";
import { Container } from "@/components/shared/Container";
import { SectionHeader } from "@/components/shared/SectionHeader";

export function HeroBenefitsSection() {
  const { heroBenefits } = landingContent;

  return (
    <section className="bg-white py-16 sm:py-20 lg:py-[120px]">
      <Container>
        <SectionHeader
          eyebrow={heroBenefits.eyebrow}
          title={heroBenefits.title}
          align="center"
          className="mx-auto"
        />
        <div className="mt-10 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {heroBenefits.items.map((item) => (
            <div
              key={item}
              className="flex gap-4 rounded-xl border border-brand-border bg-brand-ivory p-5"
            >
              <CheckCircle2 className="mt-1 h-6 w-6 shrink-0 text-brand-gold" aria-hidden="true" />
              <p className="font-medium text-brand-charcoal">{item}</p>
            </div>
          ))}
        </div>
      </Container>
    </section>
  );
}
