import { BarChart3, CheckCircle2, Compass, Sparkles } from "lucide-react";
import { landingContent } from "@/content/landing";
import { links } from "@/config/links";
import { Container } from "@/components/shared/Container";
import { CTAButton } from "@/components/shared/CTAButton";

export function HeroSection() {
  const { hero } = landingContent;

  return (
    <section id="top" className="overflow-hidden bg-brand-ivory py-16 sm:py-20 lg:py-[120px]">
      <Container className="grid items-center gap-12 lg:grid-cols-[1.06fr_0.94fr]">
        <div>
          <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-brand-border bg-white px-4 py-2 text-sm font-semibold text-brand-teal">
            <Sparkles className="h-4 w-4 text-brand-gold" aria-hidden="true" />
            {hero.eyebrow}
          </div>
          <h1 className="max-w-4xl text-4xl font-bold leading-[1.12] text-brand-charcoal sm:text-5xl lg:text-[64px] lg:leading-[1.05]">
            {hero.title}
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-8 text-brand-muted sm:text-xl">
            {hero.description}
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
            <CTAButton href={links.googleForm}>{hero.primaryCta}</CTAButton>
            <a
              href="#nhan-duoc-gi"
              className="focus-ring inline-flex min-h-12 items-center justify-center rounded-full px-5 py-3 text-sm font-semibold text-brand-teal transition hover:bg-brand-tealSoft sm:text-base"
            >
              {hero.secondaryCta}
            </a>
          </div>
          <div className="mt-6 grid gap-3 sm:grid-cols-3">
            {hero.trustPoints.map((point) => (
              <div
                key={point}
                className="rounded-xl border border-brand-border bg-white px-4 py-3 text-sm font-semibold text-brand-teal"
              >
                {point}
              </div>
            ))}
          </div>
          <p className="mt-5 max-w-xl text-sm leading-6 text-brand-muted">
            {hero.microcopy}
          </p>
        </div>

        <div className="relative">
          <div className="absolute -right-10 -top-10 h-52 w-52 rounded-full bg-brand-gold/15 blur-3xl" />
          <div className="relative rounded-2xl border border-brand-border bg-white p-5 shadow-soft sm:p-6">
            <div className="rounded-xl bg-brand-teal p-5 text-white">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.16em] text-brand-gold">
                    Self Insight Map
                  </p>
                  <h2 className="mt-2 text-2xl font-bold">Bản đồ vận hành cá nhân</h2>
                </div>
                <Compass className="h-10 w-10 text-brand-gold" aria-hidden="true" />
              </div>
              <div className="mt-8 grid gap-3">
                {["Ra quyết định", "Phản ứng áp lực", "Điểm mạnh", "Điểm nghẽn"].map(
                  (item, index) => (
                    <div
                      key={item}
                      className="flex items-center justify-between rounded-lg bg-white/10 px-4 py-3"
                    >
                      <span className="text-sm font-medium">{item}</span>
                      <span className="h-2 w-24 overflow-hidden rounded-full bg-white/20">
                        <span
                          className="block h-full rounded-full bg-brand-gold"
                          style={{ width: `${58 + index * 10}%` }}
                        />
                      </span>
                    </div>
                  ),
                )}
              </div>
            </div>
            <div className="mt-5 grid gap-3 sm:grid-cols-2">
              <div className="rounded-xl border border-brand-border bg-brand-ivory p-4">
                <CheckCircle2 className="h-5 w-5 text-brand-gold" aria-hidden="true" />
                <p className="mt-3 text-sm font-semibold text-brand-charcoal">
                  Quan sát có cấu trúc
                </p>
              </div>
              <div className="rounded-xl border border-brand-border bg-brand-tealSoft p-4">
                <BarChart3 className="h-5 w-5 text-brand-teal" aria-hidden="true" />
                <p className="mt-3 text-sm font-semibold text-brand-charcoal">
                  Gợi ý bước tiếp theo
                </p>
              </div>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}
