import { AlertCircle, Repeat2, Route } from "lucide-react";
import { landingContent } from "@/content/landing";
import { Container } from "@/components/shared/Container";
import { FeatureCard } from "@/components/shared/FeatureCard";
import { SectionHeader } from "@/components/shared/SectionHeader";

const icons = [Route, Repeat2, AlertCircle];

export function ProblemSection() {
  const { problems } = landingContent;

  return (
    <section className="bg-brand-tealSoft py-16 sm:py-20 lg:py-[120px]">
      <Container>
        <SectionHeader
          eyebrow={problems.eyebrow}
          title={problems.title}
          description={problems.description}
        />
        <div className="mt-10 grid gap-5 md:grid-cols-3">
          {problems.items.map((item, index) => (
            <FeatureCard
              key={item.title}
              icon={icons[index]}
              title={item.title}
              description={item.description}
            />
          ))}
        </div>
      </Container>
    </section>
  );
}
