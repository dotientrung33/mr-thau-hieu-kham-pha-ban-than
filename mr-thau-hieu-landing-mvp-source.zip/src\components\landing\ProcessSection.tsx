import { MailCheck, PenLine, ScrollText } from "lucide-react";
import { landingContent } from "@/content/landing";
import { Container } from "@/components/shared/Container";
import { SectionHeader } from "@/components/shared/SectionHeader";

const stepIcons = [PenLine, MailCheck, ScrollText];

export function ProcessSection() {
  const { process } = landingContent;

  return (
    <section id="quy-trinh" className="bg-white py-16 sm:py-20 lg:py-[120px]">
      <Container>
        <SectionHeader
          eyebrow={process.eyebrow}
          title={process.title}
          align="center"
          className="mx-auto"
        />
        <div className="mt-12 grid gap-5 md:grid-cols-3">
          {process.steps.map((step, index) => {
            const Icon = stepIcons[index];
            return (
              <article
                key={step.title}
                className="relative rounded-xl border border-brand-border bg-brand-ivory p-6"
              >
                <div className="mb-6 flex items-center justify-between">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-brand-teal text-white">
                    <Icon className="h-5 w-5" aria-hidden="true" />
                  </div>
                  <span className="text-4xl font-bold text-brand-gold/50">
                    0{index + 1}
                  </span>
                </div>
                <h3 className="text-xl font-bold text-brand-charcoal">{step.title}</h3>
                <p className="mt-3 leading-7 text-brand-muted">{step.description}</p>
              </article>
            );
          })}
        </div>
      </Container>
    </section>
  );
}
