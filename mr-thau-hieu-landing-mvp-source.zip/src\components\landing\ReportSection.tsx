import { FileText, Layers3 } from "lucide-react";
import { landingContent } from "@/content/landing";
import { links } from "@/config/links";
import { Container } from "@/components/shared/Container";
import { CTAButton } from "@/components/shared/CTAButton";
import { SectionHeader } from "@/components/shared/SectionHeader";

export function ReportSection() {
  const { report } = landingContent;

  return (
    <section id="bao-cao" className="bg-brand-ivory py-16 sm:py-20 lg:py-[120px]">
      <Container className="grid gap-10 lg:grid-cols-[0.95fr_1.05fr] lg:items-center">
        <div>
          <SectionHeader
            eyebrow={report.eyebrow}
            title={report.title}
            description={report.description}
          />
          <div className="mt-8">
            <CTAButton href={links.googleForm} variant="outline">
              Nhận báo cáo của bạn
            </CTAButton>
          </div>
        </div>

        <div className="rounded-2xl border border-brand-border bg-white p-5 shadow-soft sm:p-7">
          <div className="flex items-start justify-between gap-4 border-b border-brand-border pb-5">
            <div>
              <p className="text-sm font-semibold uppercase tracking-[0.16em] text-brand-gold">
                Preview
              </p>
              <h3 className="mt-2 text-2xl font-bold text-brand-teal">
                Thấu Hiểu Bản Thân
              </h3>
            </div>
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-brand-tealSoft text-brand-teal">
              <FileText className="h-6 w-6" aria-hidden="true" />
            </div>
          </div>
          <div className="mt-6 grid gap-3">
            {report.sections.map((section) => (
              <div key={section} className="flex items-center gap-3 rounded-lg bg-brand-ivory p-4">
                <Layers3 className="h-5 w-5 shrink-0 text-brand-gold" aria-hidden="true" />
                <span className="font-medium text-brand-charcoal">{section}</span>
              </div>
            ))}
          </div>
        </div>
      </Container>
    </section>
  );
}
