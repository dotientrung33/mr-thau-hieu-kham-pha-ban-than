type SectionHeaderProps = {
  eyebrow?: string;
  title: string;
  description?: string;
  align?: "left" | "center";
  className?: string;
};

export function SectionHeader({
  eyebrow,
  title,
  description,
  align = "left",
  className = "",
}: SectionHeaderProps) {
  return (
    <div
      className={`${align === "center" ? "mx-auto text-center" : ""} max-w-3xl ${className}`}
    >
      {eyebrow ? (
        <p className="mb-3 text-sm font-semibold uppercase tracking-[0.16em] text-brand-gold">
          {eyebrow}
        </p>
      ) : null}
      <h2 className="text-3xl font-bold leading-tight text-brand-charcoal sm:text-4xl lg:text-[44px]">
        {title}
      </h2>
      {description ? (
        <p className="mt-4 text-base leading-8 text-brand-muted sm:text-lg">
          {description}
        </p>
      ) : null}
    </div>
  );
}
