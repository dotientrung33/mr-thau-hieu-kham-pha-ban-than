export const links = {
  googleForm: "https://forms.gle/YCPnrnUch34T3VWH7",
  email: "hello@mrthauhieu.vn",
};
