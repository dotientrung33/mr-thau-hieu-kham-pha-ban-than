export const landingContent = {
  hero: {
    eyebrow: "Báo cáo Thấu Hiểu Bản Thân",
    title: "KHÁM PHÁ BẢN THÂN",
    description:
      "Một trải nghiệm ngắn giúp bạn nhìn rõ cách mình ra quyết định, phản ứng trước áp lực, theo đuổi mục tiêu và lặp lại những khuôn mẫu quen thuộc.",
    primaryCta: "Làm bài đánh giá ngay",
    secondaryCta: "Xem bạn sẽ nhận được gì",
    microcopy: "Thông tin của bạn chỉ dùng để gửi báo cáo và liên hệ khi phù hợp.",
    trustPoints: [
      "20 câu hỏi • 5-7 phút thực hiện",
      "Nhận báo cáo trong 24 giờ",
      "Tặng 30 phút luận giải miễn phí",
    ],
  },
  heroBenefits: {
    eyebrow: "Bạn sẽ nhận được gì?",
    title: "6 lợi ích sau khi hoàn thành bài đánh giá.",
    items: [
      "Hiểu rõ hơn cách bạn đang ra quyết định trong cuộc sống.",
      "Nhận diện những điểm mạnh đang giúp bạn tiến lên.",
      "Nhìn thấy các điểm nghẽn khiến bạn dễ trì hoãn hoặc phân vân.",
      "Có góc nhìn rõ hơn về cách bạn phản ứng trong áp lực và mối quan hệ.",
      "Nhận báo cáo cá nhân để định hướng bước tiếp theo.",
      "Được tặng 30 phút luận giải miễn phí để hiểu sâu hơn kết quả của mình.",
    ],
  },
  problems: {
    eyebrow: "Nếu bạn đang thấy mình...",
    title: "Không phải lúc nào vấn đề cũng là thiếu cố gắng.",
    description:
      "Đôi khi bạn chỉ chưa nhìn rõ hệ điều hành bên trong đang điều khiển cách mình chọn, phản ứng và bước tiếp.",
    items: [
      {
        title: "Dễ mất phương hướng",
        description:
          "Bạn biết mình muốn thay đổi, nhưng chưa chắc nên bắt đầu từ đâu.",
      },
      {
        title: "Lặp lại lựa chọn cũ",
        description:
          "Bạn nhận ra một vài tình huống quen thuộc cứ quay lại trong công việc, mối quan hệ hoặc mục tiêu.",
      },
      {
        title: "Khó gọi tên chính mình",
        description:
          "Bạn có nhiều suy nghĩ bên trong nhưng chưa có một bản đồ rõ ràng để hiểu chúng.",
      },
    ],
  },
  benefits: {
    eyebrow: "Bạn sẽ nhận được gì",
    title: "Một góc nhìn rõ hơn về cách bạn đang vận hành.",
    items: [
      "Nhìn lại cách bạn thường ra quyết định khi đứng trước lựa chọn quan trọng.",
      "Nhận diện xu hướng phản ứng của bạn khi chịu áp lực hoặc mâu thuẫn.",
      "Hiểu những điểm mạnh đang hỗ trợ bạn tiến lên.",
      "Nhìn thấy các điểm nghẽn khiến bạn dễ trì hoãn, phân tán hoặc tự nghi ngờ.",
    ],
  },
  report: {
    eyebrow: "Báo cáo cá nhân",
    title: "Báo cáo Thấu Hiểu Bản Thân",
    description:
      "Sau khi hoàn thành form, bạn sẽ được hướng dẫn nhận báo cáo giúp tổng hợp những quan sát quan trọng về cách bạn đang vận hành.",
    sections: [
      "Mẫu hình hành động nổi bật",
      "Cách bạn xử lý áp lực",
      "Điểm mạnh cần được dùng đúng chỗ",
      "Điểm nghẽn cần được nhìn rõ",
      "Gợi ý bước tiếp theo phù hợp hơn",
    ],
  },
  process: {
    eyebrow: "Quy trình",
    title: "Đơn giản, rõ ràng, không gây áp lực.",
    steps: [
      {
        title: "Trả lời form khám phá",
        description:
          "Bạn chia sẻ bối cảnh, mục tiêu, điểm mắc kẹt và cách mình thường phản ứng trong đời sống.",
      },
      {
        title: "Nhận email xác nhận",
        description:
          "Bạn nhận thông tin xác nhận và hướng dẫn tiếp theo qua email đã đăng ký.",
      },
      {
        title: "Nhận báo cáo",
        description:
          "Báo cáo giúp bạn nhìn lại bản thân có cấu trúc hơn, trước khi quyết định có cần tư vấn sâu hơn hay không.",
      },
    ],
  },
  about: {
    eyebrow: "Về Mr. Thấu Hiểu",
    title: "Đỗ Tiến Trung",
    role: "Trainer | Leadership & Relationship Coach",
    stats: ["Gần 20 năm kinh nghiệm", "Hơn 500 học viên"],
    services: [
      "Leadership Coaching",
      "Relationship Coaching",
      "Map For Success",
      "Kid Talent Map",
      "Career Map",
      "Relationship Map",
    ],
    description:
      "Mr. Thấu Hiểu tập trung vào việc giúp bạn quan sát lại cách mình đang vận hành trong cuộc sống: cách lựa chọn, cách phản ứng, cách đi qua áp lực và cách thiết kế bước tiếp theo phù hợp hơn.",
    quote:
      "Khi bạn hiểu cách mình đang vận hành, bạn không cần ép bản thân thay đổi bằng áp lực. Bạn có thể bắt đầu điều chỉnh bằng sự rõ ràng.",
  },
  finalCta: {
    title: "Bắt đầu bằng việc hiểu rõ hơn cách bạn đang vận hành.",
    description:
      "Hoàn thành bài khám phá ngắn để nhận Báo cáo Thấu Hiểu Bản Thân và mở ra bước tiếp theo phù hợp hơn cho bạn.",
    cta: "Nhận Báo Cáo Thấu Hiểu Bản Thân",
    microcopy: "Không bán coaching trực tiếp. Không ép tư vấn. Chỉ bắt đầu từ sự thấu hiểu.",
  },
};
